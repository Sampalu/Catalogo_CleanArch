﻿namespace ApiCatalogo.Pagination
{
    public class CategoriasParameters : QueryStringParameters
    {
    }
}
