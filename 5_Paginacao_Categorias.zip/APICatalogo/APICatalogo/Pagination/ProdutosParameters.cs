﻿namespace ApiCatalogo.Pagination
{
    public class ProdutosParameters : QueryStringParameters
    {
        
    }
}
